package org.example.cursospring.rapidito.api.controller;


import org.example.cursospring.rapidito.api.dto.ContratoDTO;
import org.example.cursospring.rapidito.api.service.ContratoService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/contratos")
public class ContratoController {

    private final ContratoService contratoService;

    public ContratoController(ContratoService contratoService) {
        this.contratoService = contratoService;
    }


    @GetMapping("")
    public String main(){
        return "redirect:/contratos/";
    }


    @GetMapping("/")
    public String mostrarClientes(Model model) {
        model.addAttribute("clientes", contratoService.mostrarContratos());
        return "listaContratos";
    }


    // Crear - obtener datos
    @GetMapping("/new")
    public String nuevoContrato(Model model){
        model.addAttribute("cliente", new ContratoDTO());
        model.addAttribute("editMode", true);
        return "contrato";
    }


    // Crear - guardar datos
    @PostMapping("/{id}")
    public String guardarContrato(@ModelAttribute ContratoDTO contratoDTO){
        contratoDTO = contratoService.crearContrato(contratoDTO);
        return "redirect:/contrato/" + contratoDTO.getId();
    }


    // ver
    @GetMapping("/id")
    public String mostrarContrato(Model model, @PathVariable Long id){
        model.addAttribute("contrato", contratoService.mostrarContrato(id));
        model.addAttribute("editMode", false);
        return "contrato";
    }


    // editar/actualizar
    @GetMapping("/id/edit")
    public String editarContrato(Model model, @PathVariable Long id){
        model.addAttribute("contrato", contratoService.mostrarContrato(id));
        model.addAttribute("editMode", true);
        return "contrato";
    }


    // editar/actualizar
    @PostMapping("/id/edit")
    public String actualizarContrato(@ModelAttribute ContratoDTO contratoDTO){
        contratoDTO = contratoService.actualizarContrato(contratoDTO);
        return "redirect:/contrato/" + contratoDTO.getId();
    }


    // borrar
    @GetMapping("/{id}/delete")
    public String eliminarContrato(Model model, @PathVariable Long id){
        boolean resultado = contratoService.eliminarContrato(contratoService.mostrarContrato(id));
        model.addAttribute("resultado", resultado);
        return "redirect:/contratos/";
    }

}
