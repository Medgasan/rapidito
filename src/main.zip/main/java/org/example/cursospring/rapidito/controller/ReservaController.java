package org.example.cursospring.rapidito.controller;


import org.example.cursospring.rapidito.dto.ReservaDTO;
import org.example.cursospring.rapidito.service.ReservaService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/reservas")
public class ReservaController {

    private final ReservaService reservaService;

    public ReservaController(ReservaService reservaService) {
        this.reservaService = reservaService;
    }


    @GetMapping("")
    public String main(){
        return "redirect:/reservas/";
    }


    @GetMapping("/")
    public String mostrarReservas(Model model){
        model.addAttribute("clientes", reservaService.mostrarReservas());
        return "listaReservas";
    }



    // Crear - obtener datos
    @GetMapping("/new")
    public String nuevoReserva(Model model){
        model.addAttribute("cliente", new ReservaDTO());
        model.addAttribute("editMode", true);
        return "reserva";
    }


    // Crear - guardar datos
    @PostMapping("/{id}")
    public String guardarReserva(@ModelAttribute ReservaDTO contratoDTO){
        contratoDTO = reservaService.crearReserva(contratoDTO);
        return "redirect:/reserva/" + contratoDTO.getId();
    }


    // ver
    @GetMapping("/id")
    public String mostrarReserva(Model model, @PathVariable Long id){
        model.addAttribute("contrato", reservaService.mostrarReserva(id));
        model.addAttribute("editMode", false);
        return "reserva";
    }


    // editar/actualizar
    @GetMapping("/id/edit")
    public String editarReserva(Model model, @PathVariable Long id){
        model.addAttribute("contrato", reservaService.mostrarReserva(id));
        model.addAttribute("editMode", true);
        return "reserva";
    }


    // editar/actualizar
    @PostMapping("/id/edit")
    public String actualizarReserva(@ModelAttribute ReservaDTO reservaDTO){
        reservaDTO = reservaService.actualizarReserva(reservaDTO);
        return "redirect:/reserva/" + reservaDTO.getId();
    }


    // borrar
    @GetMapping("/{id}/delete")
    public String eliminarContrato(Model model, @PathVariable Long id){
        boolean resultado = reservaService.eliminarReserva(reservaService.mostrarReserva(id));
        model.addAttribute("resultado", resultado);
        return "redirect:/reservas/";
    }



}
