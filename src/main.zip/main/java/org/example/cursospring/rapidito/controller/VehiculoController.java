package org.example.cursospring.rapidito.controller;


import org.example.cursospring.rapidito.dto.VehiculoDTO;
import org.example.cursospring.rapidito.service.VehiculoService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/vehiculos")
public class VehiculoController {

    private final VehiculoService vehiculoService;

    public VehiculoController(VehiculoService vehiculoService) {
        this.vehiculoService = vehiculoService;
    }


    @GetMapping("")
    public String main(){
        return "redirect:/vehiculos/";
    }

    // mostrar todos
    @GetMapping("/")
    public String mostrarVehiculos(Model model){
        model.addAttribute("vehiculos", vehiculoService.mostrarVehiculos());
        return "listaVehiculos";
    }


    // mostrar por marca
    @GetMapping("/{marca}/list")
    public String mostrarVehiculosPorMarca(@PathVariable String marca, Model model){
        model.addAttribute("marca", marca);
        model.addAttribute("vehiculos", vehiculoService.mostrarVehiculosPorMarca(marca));
        return "listaVehiculos";
    }


    // Crear - obtener datos
    @GetMapping("/new")
    public String nuevoVehiculo(Model model){
        model.addAttribute("vehiculo", new VehiculoDTO());
        model.addAttribute("editMode", true);
        return "vehiculo";
    }


    // Crear - guardar datos
    @PostMapping("/{id}")
    public String guardarVehiculo(@ModelAttribute VehiculoDTO vehiculoDTO){
        vehiculoDTO = vehiculoService.crearVehiculo(vehiculoDTO);
        return "redirect:/vehiculo/" + vehiculoDTO.getId();
    }


    // ver
    @GetMapping("/id")
    public String mostrarVehiculo(Model model, @PathVariable Long id){
        model.addAttribute("vehiculo", vehiculoService.mostrarVehiculo(id));
        model.addAttribute("editMode", false);
        return "vehiculo";
    }


    // editar/actualizar
    @GetMapping("/id/edit")
    public String editarVehiculo(Model model, @PathVariable Long id){
        model.addAttribute("vehiculo", vehiculoService.mostrarVehiculo(id));
        model.addAttribute("editMode", true);
        return "vehiculo";
    }


    // editar/actualizar
    @PostMapping("/id/edit")
    public String actualizarVehiculo(@ModelAttribute VehiculoDTO vehiculoDTO){
        vehiculoDTO = vehiculoService.actualizarVehiculo(vehiculoDTO);
        return "redirect:/vehiculo/" + vehiculoDTO.getId();
    }


    // borrar
    @GetMapping("/{id}/delete")
    public String eliminarVehiculo(Model model, @PathVariable Long id){
        boolean resultado = vehiculoService.eliminarVehiculo(vehiculoService.mostrarVehiculo(id));
        model.addAttribute("resultado", resultado);
        return "redirect:/";
    }

}
